function calcularMelhoEscolha() {
	precoGasolina = parseInt(document.getElementById('idGasolina').value);
	precoAlcool = parseInt(document.getElementById('idAlcool').value);
	result = precoAlcool/precoGasolina;
	if(result > 0.7) {
		document.getElementById('resultado').innerHTML = "Abasteça com Gasolina";
	} else {
		document.getElementById('resultado').innerHTML = "Abasteça com Álcool";
	}
}